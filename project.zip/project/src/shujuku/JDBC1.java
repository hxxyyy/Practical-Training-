package shujuku;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC1 {
    public static Connection lianjieshujuku() throws SQLException, ClassNotFoundException {

		Connection conn = null;
		// TODO Auto-generated method stub
                 String driver = "com.mysql.jdbc.Driver";
                  //URLָ��Ҫ���ʵ����ݿ���mydata
                 String url = "jdbc:mysql://localhost:3306/work?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
                 //MySQL����ʱ���û���
                 String user = "root";
                 //MySQL����ʱ������
                 String password = "123456";
                 Class.forName(driver);
          conn = DriverManager.getConnection(url,user,password);
          return conn;
    }
    //�ͷ���Դ
    public static void shifangziyuan(Statement stmt, Connection conn,ResultSet rs) throws SQLException {
    	if(stmt != null) {
    		stmt.close();
    		stmt = null;
    	}
    	if(conn != null) {
    		conn.close();
    		conn = null;
    	}
    	if(rs != null) {
    		rs.close();
    		rs = null;
    	}
    }
}
