package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;

import shixun.JobInformation;
import shixun.UserInformation;
import shixun.Users;

public class UsersJDBC {
	public boolean gengxinyonghu(String username,UserInformation userinformation) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		boolean o = false;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		JDBC2 jdbc2 = new JDBC2();
		ArrayList<Users> list =jdbc2.chaquanbu();
		 for(int i = 0;i <list.size();i++){
			 if(list.get(i).getUsername().equals(username)) {
				o = true;
			 }
		 }
		 if(o) {
			 String sql = "UPDATE userinformation set sex='"
		 +userinformation.getSex()+"',brith='"+userinformation.getBrith()+"',phonenum='"+userinformation.getPhonenum()
		 +"',city='"+userinformation.getCity()+"',email='"+userinformation.getEmail()
		 +"',home='"+userinformation.getHome()+"',img='"+userinformation.getImg()+"'WHERE username='"+username+"'";
			 int num = stmt.executeUpdate(sql);
				if(num > 0) {
					JDBC1.shifangziyuan(stmt, conn, rs);
					return true;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				
				return o ;
		}
		
		
		return o ;
		 }
	
	
	  public ArrayList<UserInformation> chaquanbu() throws ClassNotFoundException, SQLException {
		  Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			ArrayList<UserInformation> list = new ArrayList<UserInformation>();
			String sql = "SELECT * FROM userinformation";
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				UserInformation userinformation = new UserInformation();
				userinformation.setSex(rs.getString("sex"));
				userinformation.setBrith(rs.getString("brith"));
				userinformation.setPhonenum(rs.getString("phonenum"));
				userinformation.setCity(rs.getString("city"));
				userinformation.setEmail(rs.getString("email"));
				userinformation.setHome(rs.getString("home"));
				
			    list.add(userinformation);
	
			}
			JDBC1.shifangziyuan(stmt, conn, rs);
			return list;
			
	  } 
	  public UserInformation chaxun(String username) throws ClassNotFoundException, SQLException {
		  Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			UserInformation uif = new UserInformation();
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			String sql = "SELECT * FROM userinformation WHERE username='"+username+"'";
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				
				uif.setSex(rs.getString("sex"));
				uif.setBrith(rs.getString("brith"));
				uif.setPhonenum(rs.getString("phonenum"));
				uif.setCity(rs.getString("city"));
				uif.setEmail(rs.getString("email"));
				uif.setHome(rs.getString("home"));
				uif.setImg(rs.getString("img"));
				uif.setUsername(username);
				
			}
			JDBC1.shifangziyuan(stmt, conn, rs);
			return uif;
			
	  }
	
}
