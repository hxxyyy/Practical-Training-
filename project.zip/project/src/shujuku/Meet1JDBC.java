package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import shixun.Releasedate;
import shixun.UserInformation;
import shixun.Users;


public class Meet1JDBC {
	public boolean gengxinshuju(String username,Releasedate rld) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		boolean o = false;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		
			 String sql = "INSERT INTO releasedate(username,time,site,thing,money,pay,information)"
		 +"VALUES('"+username+"','"+rld.getTime()+"','"+rld.getSite()+"','"+rld.getThing()+"','"+rld.getMoney()+"','"+rld.getPay()+"','"+rld.getInformation()+"')";
			 int num = stmt.executeUpdate(sql);
				if(num > 0) {
					JDBC1.shifangziyuan(stmt, conn, rs);
					return true;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
			UsersJDBC uj = new UsersJDBC();
			UserInformation ufj = new UserInformation();
			ufj = uj.chaxun(username);
			String path = ufj.getImg();
			sql = "UPDATE userinformation set img='"+path+"'WHERE username='"+username+"'";
				return o ;
		 }
	
	public ArrayList<Releasedate> chaquanbu() throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		ArrayList<Releasedate> list = new ArrayList<Releasedate>();
		String sql = "SELECT * FROM releasedate";
		rs = stmt.executeQuery(sql);
		while(rs.next()) {
			Releasedate user = new Releasedate();
			user.setTime(rs.getString("time"));
			user.setSite(rs.getString("site"));
		    user.setThing(rs.getString("thing"));
		    user.setUsername(rs.getString("username"));
		    user.setMoney(rs.getString("money"));
		    user.setPay(rs.getString("pay"));
		    user.setInformation(rs.getString("information"));
		    user.setId(rs.getInt("id"));
		    list.add(user);
		}
		JDBC1.shifangziyuan(stmt, conn, rs);
		
		
		return list;
		
	}
	public Releasedate chaxun(String username) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		Releasedate rd = new Releasedate();
		String sql = "SELECT * FROM releasedate where username='"+username+"'";
		rs = stmt.executeQuery(sql);
		while(rs.next()) {
			
			rd.setTime(rs.getString("time"));
			rd.setSite(rs.getString("site"));
			rd.setThing(rs.getString("thing"));
			rd.setUsername(rs.getString("username"));
			rd.setMoney(rs.getString("money"));
			rd.setPay(rs.getString("pay"));
			rd.setInformation(rs.getString("information"));
		   
		}
		JDBC1.shifangziyuan(stmt, conn, rs);
		
		
		return rd;
		
	}
	public Releasedate chaxun2(int id) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		Releasedate rd = new Releasedate();
		
		String sql = "SELECT * FROM releasedate where id="+id+"";
		rs = stmt.executeQuery(sql);
		while(rs.next()) {
			
			rd.setTime(rs.getString("time"));
			rd.setSite(rs.getString("site"));
			rd.setThing(rs.getString("thing"));
			rd.setUsername(rs.getString("username"));
			rd.setMoney(rs.getString("money"));
			rd.setPay(rs.getString("pay"));
			rd.setInformation(rs.getString("information"));
		   
		}
		JDBC1.shifangziyuan(stmt, conn, rs);
		
		
		return rd;
	}
	public ArrayList<Releasedate> chawodeyuehui(String username) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		ArrayList<Releasedate> list = new ArrayList<Releasedate>();
		String sql = "SELECT * FROM releasedate where username='"+username+"'";
		rs = stmt.executeQuery(sql);
		while(rs.next()) {
			Releasedate user = new Releasedate();
			user.setTime(rs.getString("time"));
			user.setSite(rs.getString("site"));
		    user.setThing(rs.getString("thing"));
		    user.setUsername(rs.getString("username"));
		    user.setMoney(rs.getString("money"));
		    user.setPay(rs.getString("pay"));
		    user.setInformation(rs.getString("information"));
		    user.setId(rs.getInt("id"));
		    list.add(user);
		}
		JDBC1.shifangziyuan(stmt, conn, rs);
		
		
		return list;
		
	}
	  //ɾ
			public boolean shan(int id) throws ClassNotFoundException, SQLException {
				Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				
				String sql = "DELETE FROM releasedate WHERE id="+id;
				int num = stmt.executeUpdate(sql);
				if(num >0) {
					JDBC1.shifangziyuan(stmt, conn, rs);
					return true;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return false;
			
			}
	
}
