package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.catalina.User;

import shixun.Users;



public class JDBC2 {
	   //��
		public boolean zeng(Users user) throws ClassNotFoundException, SQLException {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			boolean o = true;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			 ArrayList<Users> list = this.chaquanbu();
			 for(int i = 0;i <list.size();i++){
				 if(list.get(i).getUsername().equals(user.getUsername())||list.get(i).getPhonenum().equals(user.getPhonenum())) {
					 o = false;
				 }
			 }
			 if(o) {
			String sql = "INSERT INTO users(username,password,email,phonenum,realname)"+
			"VALUES('"+user.getUsername()+"','"+user.getPassword()+"','"+user.getEmail()+"','"+user.getPhonenum()+"','"+user.getRealname()+"')";
			int num = stmt.executeUpdate(sql);
			if(num > 0) {
				JDBC1.shifangziyuan(stmt, conn, rs);
				return true;
			}
			JDBC1.shifangziyuan(stmt, conn, rs);
			
			return o ;
			 }
			
			return o;
			
			
		
			
		}
	   //ɾ
		public boolean shan(String name) throws ClassNotFoundException, SQLException {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			
			String sql = "DELETE FROM users WHERE username='"+name+"'";
			int num = stmt.executeUpdate(sql);
			if(num >0) {
				JDBC1.shifangziyuan(stmt, conn, rs);
				return true;
			}
			JDBC1.shifangziyuan(stmt, conn, rs);
			return false;
		
		}
	   //��
		  public boolean gai(Users user)throws ClassNotFoundException, SQLException {
			  Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				String sql = "UPDATE users set username='"+user.getUsername()+"',password='"+user.getPassword()+"'WHERE username='"+user.getUsername()+"'";
				
				int num = stmt.executeUpdate(sql);
				if(num >0) {
					JDBC1.shifangziyuan(stmt, conn, rs);
					return true;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return false;
		  }
	   //��
		  public  ArrayList<Users> chaquanbu() throws ClassNotFoundException, SQLException {
			  Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				ArrayList<Users> list = new ArrayList<Users>();
				String sql = "SELECT * FROM users";
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					Users user = new Users();
					user.setId(rs.getInt("id"));
					user.setUsername(rs.getString("username"));
				    user.setEmail(rs.getString("email"));
				    user.setPhonenum(rs.getString("phonenum"));
				    user.setPassword(rs.getString("password"));
				    list.add(user);
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return list;
				
		  } 
		  public Users find(String name) throws ClassNotFoundException, SQLException {
			  Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				String sql = "SELECT * FROM users WHERE username='"+name+"'";
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					Users user = new Users();
					user.setPassword(rs.getString("password"));
					user.setUsername(rs.getString("username"));
					user.setEmail(rs.getString("email"));
					user.setPhonenum(rs.getString("phonenum"));
					return user;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return null;
				
		  }
}
