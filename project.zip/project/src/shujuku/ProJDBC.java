package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import shixun.Promulgator;
import shixun.Releasedate;
import shixun.UserInformation;

public class ProJDBC {

	
		public boolean gengxinshuju(String username, Promulgator plt) throws ClassNotFoundException, SQLException {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			boolean o = true;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			ArrayList<Promulgator> list = new ArrayList<>();
            list = this.chaquanbu();
            
            for(int i = 0; i<list.size();i++) {
            	if(username.equals(list.get(i).getUsername())) {
            		o = false;
            	}
            }
            if(o) {
            	 
			String sql = "INSERT INTO promulgator(username,sex,nianling,job)" + "VALUES('" + username + "','" + plt.getSex()
					+ "','" + plt.getAge() + "','" + plt.getJob() + "')";
			int num = stmt.executeUpdate(sql);
			if (num > 0) {
			JDBC1.shifangziyuan(stmt, conn, rs);
			}
            }
			JDBC1.shifangziyuan(stmt, conn, rs);
			return o;
		}

		public ArrayList<Promulgator> chaquanbu() throws SQLException, ClassNotFoundException {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			ArrayList<Promulgator> list = new ArrayList<Promulgator>();
			String sql = "SELECT * FROM promulgator";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Promulgator user = new Promulgator();
				user.setSex(rs.getString("sex"));
				user.setJob(rs.getString("job"));
				user.setAge(rs.getString("nianling"));
				user.setUsername(rs.getString("username"));
				list.add(user);
			}
			JDBC1.shifangziyuan(stmt, conn, rs);

			return list;
		}
	}


