package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import shixun.StudentInformation;
import shixun.Users;



public class JDBC3 {
	   //��
		public boolean gengxinyonghu(String username,StudentInformation student) throws ClassNotFoundException, SQLException {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			boolean o = false;
			conn = JDBC1.lianjieshujuku();
			stmt = conn.createStatement();
			JDBC2 jdbc2 = new JDBC2();
			ArrayList<Users> list =jdbc2.chaquanbu();
			 for(int i = 0;i <list.size();i++){
				 if(list.get(i).getUsername().equals(username)) {
					o = true;
				 }
			 }
			 if(o) {
				 String sql = "UPDATE studentinformation set school='"
			 +student.getSchool()+"',study='"+student.getStudy()+"',start='"+student.getStart()
			 +"',finish='"+student.getFinish()+"',education='"+student.getEducation()
			 +"',correlation='"+student.getCorrelation()+"',information='"+student.getInformation()+"'WHERE username='"+username+"'";
				 int num = stmt.executeUpdate(sql);
					if(num > 0) {
						JDBC1.shifangziyuan(stmt, conn, rs);
						return true;
					}
					JDBC1.shifangziyuan(stmt, conn, rs);
					
					return o ;
			}
			
			
			return o ;
			 }
			
			
			
		
			
	   //��
		  public ArrayList<StudentInformation> chaquanbu() throws ClassNotFoundException, SQLException {
			  Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				ArrayList<StudentInformation> list = new ArrayList<StudentInformation>();
				String sql = "SELECT * FROM studentinformation";
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					StudentInformation student = new StudentInformation();
					student.setSchool(rs.getString("school"));
					student.setStart(rs.getString("start"));
				    student.setCorrelation(rs.getString("correlation"));
				    student.setEducation(rs.getString("education"));
				    student.setFinish(rs.getString("finish"));
				    student.setinformation(rs.getString("information"));
				    student.setStudy(rs.getString("study"));
				    list.add(student);
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return list;
				
		  } 
//		  public Users find(String name) throws ClassNotFoundException, SQLException {
//			  Connection conn = null;
//				Statement stmt = null;
//				ResultSet rs = null;
//				conn = JDBC1.lianjieshujuku();
//				stmt = conn.createStatement();
//				String sql = "SELECT * FROM users WHERE username='"+name+"'";
//				rs = stmt.executeQuery(sql);
//				while(rs.next()) {
//					Users user = new Users();
//					user.setPassword(rs.getString("password"));
//					user.setUsername(rs.getString("username"));
//					user.setEmail(rs.getString("email"));
//					user.setPhonenum(rs.getString("phonenum"));
//					return user;
//				}
//				JDBC1.shifangziyuan(stmt, conn, rs);
//				return null;
//				
//		  }
}
