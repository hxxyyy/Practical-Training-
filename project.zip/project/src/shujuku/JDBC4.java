package shujuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import shixun.JobInformation;
import shixun.StudentInformation;
import shixun.Users;

public class JDBC4 {
	public boolean gengxinyonghu(String username,JobInformation jobinformation) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		boolean o = false;
		conn = JDBC1.lianjieshujuku();
		stmt = conn.createStatement();
		JDBC2 jdbc2 = new JDBC2();
		ArrayList<Users> list =jdbc2.chaquanbu();
		 for(int i = 0;i <list.size();i++){
			 if(list.get(i).getUsername().equals(username)) {
				o = true;
			 }
		 }
		 if(o) {
			 String sql = "UPDATE jobinformation set job='"
		 +jobinformation.getJob()+"',workcity='"+jobinformation.getWorkcity()+"',start='"+jobinformation.getStart()
		 +"',finish='"+jobinformation.getFinish()+"',correlation='"+jobinformation.getCorrelation()
		 +"',description='"+jobinformation.getDescription()+"',company='"+jobinformation.getCompany()+"'WHERE username='"+username+"'";
			 int num = stmt.executeUpdate(sql);
				if(num > 0) {
					JDBC1.shifangziyuan(stmt, conn, rs);
					return true;
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				
				return o ;
		}
		
		
		return o ;
		 }
	   //��
		  public ArrayList<JobInformation> chaquanbu() throws ClassNotFoundException, SQLException {
			  Connection conn = null;
				Statement stmt = null;
				ResultSet rs = null;
				conn = JDBC1.lianjieshujuku();
				stmt = conn.createStatement();
				ArrayList<JobInformation> list = new ArrayList<JobInformation>();
				String sql = "SELECT * FROM jobinformation";
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					JobInformation jobinformation = new JobInformation();
					jobinformation.setJob(rs.getString("job"));
					jobinformation.setStart(rs.getString("start"));
					jobinformation.setWorkcity(rs.getString("workcity"));
					jobinformation.setCorrelation(rs.getString("correlation"));
					jobinformation.setFinish(rs.getString("finish"));
					jobinformation.setDescription(rs.getString("description"));
					jobinformation.setCompany(rs.getString("company"));
				    list.add(jobinformation);
				}
				JDBC1.shifangziyuan(stmt, conn, rs);
				return list;
				
		  } 
		
}
