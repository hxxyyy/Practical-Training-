package shujuku;

import java.sql.SQLException;
import java.util.ArrayList;

import shixun.Users;

public class demo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
      JDBC2 jd2 = new JDBC2();
      Users user = new Users();
      user.setUsername("3");
      user.setPassword("1");
      user.setEmail("1");
      user.setPhonenum("3");
      jd2.zeng(user);
      Users user2 = jd2.find("2");
      System.out.println("email:"+user2.getEmail()+" name:"+user2.getUsername());
      Users user3 = new Users();
      user3.setPassword("123");
      user3.setUsername("2");
      jd2.gai(user3);
      user2 = jd2.find("2");
      System.out.println("email:"+user2.getEmail()+" name:"+user2.getUsername()+" password:"+user2.getPassword());
      
      
      ArrayList<Users> list = jd2.chaquanbu();
      for(int i = 0;i<list.size();i++) {
    	  System.out.println("id:" + list.get(i).getId()+" name:"+list.get(i).getUsername()+
    			  " email:"+list.get(i).getEmail()+" phone:"+list.get(i).getPhonenum()+" password:"+list.get(i).getPassword());
      }
	}
	
	

}
