package shujuku;

import java.sql.SQLException;
import java.util.ArrayList;

import shixun.Promulgator;
import shixun.Releasedate;
import shixun.StudentInformation;
import shixun.UserInformation;
import shixun.Users;

public class text3 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		// TODO Auto-generated method stub
//      JDBC3 jd3 = new JDBC3();
//      StudentInformation student = new StudentInformation();
//      
//      jd3.gengxinyonghu("9", student);
		
//		JDBC2 jd2 = new JDBC2();
//		Users user = new Users();
//		user.setUsername("123456");
//		
//		System.out.println(jd2.zeng(user));
		
//		UsersJDBC ujdc = new UsersJDBC();
//		UserInformation userinformation = new UserInformation();
//		userinformation.setBrith("10");
//		userinformation.setCity("�ɶ�");
//		ujdc.gengxinyonghu("��", userinformation);
//		Releasedate rld = new Releasedate();
//		rld.setUsername("����ΰ");
//		rld.setMoney("100");
//		rld.setPay("AA");
//		rld.setSite("��ӰԺ");
//		rld.setThing("�����Ӱ�Ե㷹");
//		rld.setTime("����");
//		rld.setInformation("ϣ���Ҹ�־ͬ���ϵ���");
//		
//		Meet1JDBC m1 = new Meet1JDBC();
////		m1.gengxinshuju("����ΰ", rld);
//		ArrayList<Releasedate> list = new ArrayList<>();
//		list = m1.chaquanbu();
//		for(int i = 0;i<list.size();i++) {
//			System.out.println(list.get(i).getInformation());
//		}
//		
//		UserInformation ufi = new UserInformation();
//		UsersJDBC uj = new UsersJDBC();
//		ufi = uj.chaxun("19980703");
//		System.out.println(ufi.getImg());
//		ProJDBC prj = new ProJDBC();
//		Promulgator prm = new Promulgator();
//	    System.out.println(prj.gengxinshuju("����ΰ8", prm));
//		ProJDBC pj = new ProJDBC();
//		UsersJDBC uj = new UsersJDBC();
//	    UserInformation ui = new UserInformation();
//	    try {
//			ui = uj.chaxun("����");
//			   
//		    Promulgator pgo = new Promulgator();
//		    pgo.setSex(ui.getSex());
//		    
//			pj.gengxinshuju("����",pgo);
//		} catch (ClassNotFoundException | SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		ArrayList<Integer> list1 = new ArrayList<>();
		int c = 0;
		for(int i = 0;i<=9;i++) {
			list1.add(i);
		}
		int b = (list1.size()/6)+1;
		Integer[][] list2 = new Integer[b][6];
		int a = 0;
		for(int j = 0 ;j<list2.length;j++) {
			for(int k = 0;k<list2[j].length;k++) {
				if(list1.size()>(a+k)) {
				list2[j][k] = list1.get(a+k);
				c = k;
				}
				
			}
			a += (c+1);
	}
		System.out.println(list2.length);
		System.out.println(list2[0].length);
		
		for(int i = 0; i<list2.length;i++) {
			for(int j = 0;j<list2[i].length;j++) {
				System.out.println(list2[i][j]);
			}
		}
	}
		
		
	}


