package web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javabean.Studentmsg;
import shixun.JobInformation;
import shixun.Users;
import shujuku.JDBC3;
import shujuku.JDBC4;

/**
 * Servlet implementation class jobServlet
 */
@WebServlet("/jobServlet")
public class jobServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public jobServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setHeader("Content-type","text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		

		String company = request.getParameter("company");
		company = new String(company.getBytes("iso8859-1"),"utf-8");
		String job = request.getParameter("job");
		job = new String(job.getBytes("iso8859-1"),"utf-8");
		String start = request.getParameter("start");
		String finish = request.getParameter("finish");
		String workcity = request.getParameter("workcity");
		workcity = new String(workcity.getBytes("iso8859-1"),"utf-8");
		String correlation = request.getParameter("correlation");
		correlation = new String(correlation.getBytes("iso8859-1"),"utf-8");
		String description = request.getParameter("description");
		description = new String(description.getBytes("iso8859-1"),"utf-8");
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("us");
		
		JobInformation job1 = new JobInformation();
		job1.setCorrelation(correlation);
		job1.setDescription(description);
		job1.setFinish(finish);
		job1.setStart(start);
		job1.setWorkcity(workcity);
		job1.setJob(job);
		job1.setCompany(company);
		JDBC4 jd4 = new JDBC4();
		try {
			jd4.gengxinyonghu(user.getUsername(), job1);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Studentmsg msg = new Studentmsg();
		if(msg.errormsg()) {
			
		}
		request.setAttribute("jobi", job1);
		request.getRequestDispatcher("/geren.jsp").forward(request, response);
		response.setHeader("refresh", "0;url=geren.jsp"); 
		doGet(request, response);
		
		
	}

}
