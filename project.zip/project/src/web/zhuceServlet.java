package web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javabean.RegisterFormBean;
import shixun.Users;
import shujuku.JDBC2;




/**
 * Servlet implementation class zhuceServlet
 */
@WebServlet("/zhuceServlet")
public class zhuceServlet extends HttpServlet {
	private boolean b ;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public zhuceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setHeader("Content-type","text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		

		String username = request.getParameter("username");
		username = new String(username.getBytes("iso8859-1"),"utf-8");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		String email = request.getParameter("email");
		String phonenum = request.getParameter("phonenum");
		String realname = request.getParameter("realname");
		realname = new String(username.getBytes("iso8859-1"),"utf-8");
		
		

		RegisterFormBean formBean = new RegisterFormBean();
		formBean.setUsername(username);
		formBean.setPassword(password);
		formBean.setPassword2(password2);
		formBean.setEmail(email);
		formBean.setPhonenum(phonenum);
		
		
		if(!formBean.errormsg()) {
			request.setAttribute("formBean", formBean);
			request.getRequestDispatcher("/zhuce.jsp").forward(request, response);   //   ������ľ������תҳ�棡����
			return;
		}
		Users user = new Users();
		user.setEmail(email);
		user.setUsername(username);
		user.setPhonenum(phonenum);
		user.setPassword(password);
		user.setRealname(realname);
		request.getSession().setAttribute("user", user);
		
		
		try {
			JDBC2 jd2 = new JDBC2();
			b = jd2.zeng(user);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!b) {
			request.setAttribute("DBMes", "��ע����û��Ѵ��ڣ�");
			request.setAttribute("formBean", formBean);
			request.getRequestDispatcher("/zhuce.jsp").forward(request, response);   // ����תҳ�棡����
			return;
		}
		else if(b){
			response.getWriter().println("��ϲ��ע��ɹ���3����Զ���ת");
		request.getSession().setAttribute("user", user);
		response.setHeader("refresh", "0;url=index.jsp");   //  ����תҳ�棡����
		
		}
		
		
	
		doGet(request, response);
		
	}

}
