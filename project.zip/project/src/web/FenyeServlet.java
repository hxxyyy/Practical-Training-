package web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import shixun.Releasedate;
import shujuku.Meet1JDBC;

/**
 * Servlet implementation class FenyeServlet
 */
@WebServlet("/FenyeServlet")
public class FenyeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FenyeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Releasedate> list1 = new ArrayList<>();
		
		Meet1JDBC mj = new Meet1JDBC();
		int a = 0;
		int c = 0;
		try {
			list1 = mj.chaquanbu();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int b = (list1.size()/6)+1;
		Releasedate[][] list2 = new Releasedate[b][6];
		
			if(list1.size()<=6) {
				
			}
			else if(list1.size()>6) {
				for(int j = 0 ;j<list2.length;j++) {
					for(int k = 0;k<list2[j].length;k++) {
						if(list1.size()>(a+k)) {
						list2[j][k] = list1.get(a+k);
						c = k;
						}
						
					}
					a += (c+1);
			}
		}   
			
			
			request.getSession().setAttribute("erwei", list2);
			request.getSession().setAttribute("yeshu", b);
			response.setHeader("refresh", "0;url=appointment.jsp");
		
		
		
		doGet(request, response);
	}

}
