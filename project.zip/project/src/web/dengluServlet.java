package web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javabean.Denglumsg;
import shixun.Users;

/**
 * Servlet implementation class dengluServlet
 */
@WebServlet("/dengluServlet")
public class dengluServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ArrayList<Users> list = new ArrayList<Users>();
	private String name;
	private boolean flag = true;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public dengluServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setHeader("Content-type","text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		
		
		String username = request.getParameter("username");
		username = new String(username.getBytes("iso8859-1"),"utf-8");
		String password = request.getParameter("password");
		password = new String(password.getBytes("iso8859-1"),"utf-8");
		
		
		Denglumsg dm = new Denglumsg();
		dm.setPassword(password);
		dm.setUsername(username);
		try {
			if(!dm.errormsg()) {
				request.setAttribute("dm", dm);
				request.getRequestDispatcher("/index.jsp").forward(request, response);   //   ������ľ������תҳ�棡����
				return;
			}
			else{
				Users us = new Users();
				us.setUsername(username);
				us.setPassword(password);
				request.getSession().setAttribute("us", us);
				response.setHeader("refresh", "0;url=geren.jsp");
				
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doGet(request, response);
//		boolean a = false;
//		for (int i = 0; i < list.size(); i++) {
//			if (username.equals(list.get(i).getUsername())) {
//				a = true;
//			}
//		}
//		if (!a) {
//			flag = false;
//		}
//		boolean b = false;
//		for (int i = 0; i < list.size(); i++) {
//
//			if (username.equals(list.get(i).getUsername())) {
//				name = list.get(i).getUsername();
//			}
//			if (password.equals(list.get(i).getPassword())) {
//				b = true;
//			}
//		}
//		if (!b) {
//			flag = false;
//		}
		
		
		
//		if(!flag) {
//			request.setAttribute("dlmsg", "�����˺Ż������������");
//			request.setAttribute("dm",dm);
//			request.getRequestDispatcher("/zhucejiemian.jsp").forward(request, response);  //����ľ�����תҳ��
//			return;
//		}
//		else if(flag){
//        
//	
//		}
		
	}
     
}
