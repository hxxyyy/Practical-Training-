package web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javabean.Studentmsg;
import shixun.StudentInformation;
import shixun.Users;
import shujuku.JDBC3;

/**
 * Servlet implementation class studentChuCunServlet
 */
@WebServlet("/studentChuCunServlet")
public class studentChuCunServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public studentChuCunServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setHeader("Content-type","text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		
		String school = request.getParameter("school");
		school = new String(school.getBytes("iso8859-1"),"utf-8");
		String study = request.getParameter("study");
		study = new String(study.getBytes("iso8859-1"),"utf-8");
		String start = request.getParameter("start");
		String finish = request.getParameter("finish");
		String education = request.getParameter("education");
		education = new String(education.getBytes("iso8859-1"),"utf-8");
		String correlation = request.getParameter("correlation");
		correlation = new String(correlation.getBytes("iso8859-1"),"utf-8");
		String information = request.getParameter("information");
		information = new String(information.getBytes("iso8859-1"),"utf-8");
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("us");
		
		StudentInformation student = new StudentInformation();
		student.setSchool(school);
		student.setStart(start);
		student.setFinish(finish);
		student.setinformation(information);
		student.setStudy(study);
		student.setEducation(education);
		student.setCorrelation(correlation);
		
		JDBC3 jd3 = new JDBC3();
		try {
			jd3.gengxinyonghu(user.getUsername(), student);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Studentmsg msg = new Studentmsg();
		if(msg.errormsg()) {
			
		}
		request.setAttribute("student", student);
		request.getRequestDispatcher("/geren.jsp").forward(request, response);
		response.setHeader("refresh", "0;url=geren.jsp"); 
		doGet(request, response);
		
		
	}

}
