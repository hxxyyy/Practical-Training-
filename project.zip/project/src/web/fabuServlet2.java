package web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import shixun.Releasedate;
import shixun.Users;
import shujuku.Meet1JDBC;

/**
 * Servlet implementation class fabuServlet2
 */
@WebServlet("/fabuServlet2")
public class fabuServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fabuServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
	    Users user = (Users) session.getAttribute("us");
	    
	    String thing = request.getParameter("thing");
	    thing = new String(thing.getBytes("iso8859-1"),"utf-8");
		String pay = request.getParameter("pay");
		pay =  new String(pay.getBytes("iso8859-1"),"utf-8");
		String site = request.getParameter("site");
		site = new String(site.getBytes("iso8859-1"),"utf-8");
		String information = request.getParameter("information");
		information =  new String(information.getBytes("iso8859-1"),"utf-8");
		String time = request.getParameter("time");
		time =  new String(time.getBytes("iso8859-1"),"utf-8");
		Releasedate rld = new Releasedate();
		rld.setInformation(information);
		rld.setPay(pay);
		rld.setSite(site);
		rld.setTime(time);
		rld.setThing(thing);
		Meet1JDBC mj = new Meet1JDBC();
		try {
			mj.gengxinshuju(user.getUsername(), rld);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setHeader("refresh", "0;url=appointment.jsp"); 
		
		
		doGet(request, response);
	}

}
