package web;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javabean.Studentmsg;
import shixun.UserInformation;
import shixun.Users;
import shujuku.JDBC4;
import shujuku.UsersJDBC;

/**
 * Servlet implementation class userServlet
 */
@WebServlet("/userServlet")
public class userServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<String> pList = new ArrayList<>();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


		
		UserInformation uif = new UserInformation();
		
		UsersJDBC ujdbc = new UsersJDBC();
		try {
			  request.getParameter("");                   //���������ļ�����
	            DiskFileItemFactory fileItemFactory =  new DiskFileItemFactory();
	            //���������ļ���
	            ServletFileUpload fileUpload = new ServletFileUpload(fileItemFactory);
	            fileUpload.setHeaderEncoding("UTF-8");// ��������ļ����ϴ�����.
	            //�����ϴ���
	            List<FileItem> list = fileUpload.parseRequest(request);
	            Map<String,String> map = new HashMap<String,String>();
	            String fileName = null;
	            for (FileItem fileItem : list) {
	                if(fileItem.isFormField()){
	                    //����Ǳ�����
	                    String name = fileItem.getFieldName();
	                    String string = fileItem.getString("utf-8");
	                    //������ļ���
	                    map.put(name, string);
	                }else{
	                    //�ϴ���
	                    fileName = fileItem.getName();
	                    fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
	                    fileName = UUID.randomUUID().toString() + "_" + fileName;
	                    InputStream is = fileItem.getInputStream();
	                    
	                    // ����ļ�Ҫ�ϴ���·���������·�������Զ��壩:
	                    String path = request.getServletContext().getRealPath("\\img");
	                    //String path = ("D:\\apache-tomcat-9.0.11\\webapps\\shixun\\images");//�����·��
	                    String dizhi = "/"+fileName;
	                    OutputStream os = new FileOutputStream(path+"/"+fileName);//cs.jpg
	                    uif.setImg(dizhi);
	                    byte[] byts = new byte[1024];
	                    int len = 0;
	                    while ((len = is.read(byts)) != -1 ) {
	                        os.write(byts, 0, len);
	                        os.flush();
	                    }
	                    
	                    
	                  
	
//	                  IOUtils.copy(is, os);
	                    //is.close();
	                    //os.close();
	                }
	       
	            }
	           
//	          BeanUtils.populate();   //��ʵ���Ӧ�����Ը���ʵ�壨�ռ����ݣ�
	            if (!fileName.equals(null)&&!fileName.equals("")) {
	                //��ͼƬ·������ʵ���ĳ������                    
	            }
	            
	        //��ʵ�������д�뵽���ݿ�
	    		
	    		String sex = map.get("sex");
	    		String birth = map.get("birth");
	    		String city = map.get("city1");
	    		String home = map.get("home");
	    		String realname = map.get("realname");
//	    		//sex = new String(sex.getBytes("iso8859-1"),"utf-8");
//	    		String brith = request.getParameter("brith");
//	    		//brith = new String(brith.getBytes("iso8859-1"),"utf-8");
//	    		String city = request.getParameter("city1");
//	    		//city = new String(city.getBytes("iso8859-1"),"utf-8");
//	    		String home = request.getParameter("home");
//	    		//home = new String(home.getBytes("iso8859-1"),"utf-8");   
	    		HttpSession session = request.getSession();
    		    Users user = (Users) session.getAttribute("us");

//	    		
	    		uif.setBrith(birth);
	    		uif.setCity(city);
	    		uif.setHome(home);
	    		uif.setSex(sex);
	    		uif.setRealname(realname);
	            
	    		
//	    		
			ujdbc.gengxinyonghu(user.getUsername(), uif);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileUploadException e) {
			
			e.printStackTrace();
		     }
		
		request.setAttribute("uif", uif);
		request.getRequestDispatcher("/geren.jsp").forward(request, response);
		response.setHeader("refresh", "0;url=geren.jsp"); 
		doGet(request, response);
		
	}
	
	

}
