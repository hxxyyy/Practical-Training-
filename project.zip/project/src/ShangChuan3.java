

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import shixun.UserInformation;
import shujuku.UsersJDBC;

/**
 * Servlet implementation class ShangChuan3
 */
@WebServlet("/ShangChuan3")
public class ShangChuan3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShangChuan3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    try {
//          request.getParameter("");                   //���������ļ�����
            DiskFileItemFactory fileItemFactory =  new DiskFileItemFactory();
            //���������ļ���
            ServletFileUpload fileUpload = new ServletFileUpload(fileItemFactory);
//          fileUpload.setHeaderEncoding("utf-8");
            fileUpload.setHeaderEncoding("UTF-8");// ��������ļ����ϴ�����.
            //�����ϴ���
            List<FileItem> list = fileUpload.parseRequest(request);
            Map<String,String> map = new HashMap<String,String>();
            String fileName = null;
            for (FileItem fileItem : list) {
                if(fileItem.isFormField()){
                    //����Ǳ�����
                    String name = fileItem.getFieldName();
                    String string = fileItem.getString("utf-8");
                    //������ļ���
                    map.put(name, string);
                }else{
                    //�ϴ���
                    fileName = fileItem.getName();
                    fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
                    fileName = UUID.randomUUID().toString() + "_" + fileName;
                    InputStream is = fileItem.getInputStream();
                    
                    // ����ļ�Ҫ�ϴ���·���������·�������Զ��壩:
                    String path = request.getServletContext().getRealPath("\\img");
                    //String path = ("D:\\apache-tomcat-9.0.11\\img");//�����·��
                    String dizhi = path+"/"+fileName;
                    OutputStream os = new FileOutputStream(path+"/"+fileName);//cs.jpg
                    UserInformation user = new UserInformation();
                    user.setImg(dizhi);
                    UsersJDBC ujdbc = new UsersJDBC();
                    ujdbc.gengxinyonghu("����ΰ3",user);
                    
                    
                    byte[] byts = new byte[1024];
                    int len = 0;
                    while ( (len = is.read(byts)) != -1 ) {
                        os.write(byts, 0, len);
                        os.flush();
                    }
//                  IOUtils.copy(is, os);
                    is.close();
                    os.close();
                }
            }
           
//          BeanUtils.populate();   //��ʵ���Ӧ�����Ը���ʵ�壨�ռ����ݣ�
            if (!fileName.equals(null)&&!fileName.equals("")) {
                //��ͼƬ·������ʵ���ĳ������                    
            }
            
        //��ʵ�������д�뵽���ݿ�
	} catch (FileUploadException e) {
	
	e.printStackTrace();
     } catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
