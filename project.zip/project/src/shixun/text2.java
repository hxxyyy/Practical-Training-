package shixun;

import java.sql.SQLException;

import javabean.RegisterFormBean;
import shujuku.Meet1JDBC;
import shujuku.UsersJDBC;

public class text2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		RegisterFormBean r = new RegisterFormBean();
//		r.setPassword("123456");
//		r.setPassword2("123456");
//		r.setUsername("����ΰ");
//		r.setPhonenum("123456");
//		r.setEmail("123456");
//		
//		System.out.println(r.errormsg());
//		StudentInformation student = new StudentInformation();
//		student.getSchool();
		
		UserInformation uf = new UserInformation();
		UsersJDBC uj = new UsersJDBC();
		Meet1JDBC mj = new Meet1JDBC();
		Releasedate rl = new Releasedate();
		try {
			uf = uj.chaxun("����ΰ");
			rl = mj.chaxun("����ΰ");
			System.out.println(uf.getUsername()+uf.getCity());
			System.out.println(rl.getPay()+rl.getInformation()+rl.getSite());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
