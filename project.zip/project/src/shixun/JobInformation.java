package shixun;

public class JobInformation {
   private String username;
   private String job;
   private String workcity;
   private String start;
   private String finish;
   private String correlation;
   private String description;
   private String company;
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getJob() {
	return job;
}
public void setJob(String job) {
	this.job = job;
}
public String getWorkcity() {
	return workcity;
}
public void setWorkcity(String workcity) {
	this.workcity = workcity;
}
public String getStart() {
	return start;
}
public void setStart(String start) {
	this.start = start;
}
public String getFinish() {
	return finish;
}
public void setFinish(String finish) {
	this.finish = finish;
}
public String getCorrelation() {
	return correlation;
}
public void setCorrelation(String correlation) {
	this.correlation = correlation;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
   
}
