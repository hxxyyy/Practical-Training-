package shixun;

public class UserInformation {
  private String username;
  private String sex;
  private String brith;
  private String phonenum;
  private String city;
  private String email;
  private String home;
  private String img;
  private String realname;
public String getRealname() {
	return realname;
}
public void setRealname(String realname) {
	this.realname = realname;
}
public String getImg() {
	return img;
}
public void setImg(String img) {
	this.img = img;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getBrith() {
	return brith;
}
public void setBrith(String brith) {
	this.brith = brith;
}
public String getPhonenum() {
	return phonenum;
}
public void setPhonenum(String phonenum) {
	this.phonenum = phonenum;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getHome() {
	return home;
}
public void setHome(String home) {
	this.home = home;
}
  
}
