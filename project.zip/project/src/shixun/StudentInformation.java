package shixun;

public class StudentInformation {
   private String username;
   private String school;
   private String study;
   private String start;
   private String finish;
   private String education;
   private String correlation;
   private String information;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getSchool() {
	return school;
}
public void setSchool(String school) {
	this.school = school;
}
public String getStudy() {
	return study;
}
public void setStudy(String study) {
	this.study = study;
}
public String getStart() {
	return start;
}
public void setStart(String start) {
	this.start = start;
}
public String getFinish() {
	return finish;
}
public void setFinish(String finish) {
	this.finish = finish;
}
public String getEducation() {
	return education;
}
public void setEducation(String education) {
	this.education = education;
}
public String getCorrelation() {
	return correlation;
}
public void setCorrelation(String correlation) {
	this.correlation = correlation;
}
public String getInformation() {
	return information;
}
public void setinformation(String information) {
	this.information = information;
}
   
   
}
