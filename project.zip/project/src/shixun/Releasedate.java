package shixun;

public class Releasedate {
   private String time;
   private String site;
   private String thing;
   private String username;
   private String money;
   private String pay;
   private String information;
   private String img;
   private int id;
   
   
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getImg() {
	return img;
}
public void setImg(String img) {
	this.img = img;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getSite() {
	return site;
}
public void setSite(String site) {
	this.site = site;
}
public String getThing() {
	return thing;
}
public void setThing(String thing) {
	this.thing = thing;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getMoney() {
	return money;
}
public void setMoney(String money) {
	this.money = money;
}
public String getPay() {
	return pay;
}
public void setPay(String pay) {
	this.pay = pay;
}
public String getInformation() {
	return information;
}
public void setInformation(String information) {
	this.information = information;
}
   
}
