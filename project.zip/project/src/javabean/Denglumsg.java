package javabean;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import shixun.Users;
import shujuku.JDBC2;

public class Denglumsg {
	private String username;
	private String password;
	private boolean flag = true;
	private int c;
	private ArrayList<Users> list = new ArrayList<Users>();
	private Map<String, String> errors = new HashMap<String, String>();

	public Map<String, String> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean errormsg() throws ClassNotFoundException, SQLException {
		JDBC2 jd = new JDBC2();
		list = jd.chaquanbu();

		boolean a = false;
		for (int i = 0; i < list.size(); i++) {
			if (username.equals(list.get(i).getUsername())) {
				a = true;
			}
		}
		if (!a) {
			errors.put("username", "��������ȷ����");
			flag = false;
		}
		boolean b = false;
		for (int i = 0; i < list.size(); i++) {

			if (username.equals(list.get(i).getUsername())) {
				c = i;
			}
			if (password.equals(list.get(c).getPassword())) {
				b = true;
			}
		}
		if (!b) {
			errors.put("password", "��������ȷ����");
			flag = false;
		}

		return flag;

	}
}
