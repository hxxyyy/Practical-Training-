package javabean;

import java.sql.SQLException;

public class text {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
     Denglumsg dl = new Denglumsg();
     dl.setUsername("����");
     dl.setPassword("1234567");
//     if(!dl.errormsg()) {
//    	 System.out.println(dl.getErrors().get("password")+dl.getErrors().get("username"));
//     }
     System.out.println(!dl.errormsg());
     
	}

}
