package javabean;

import java.util.HashMap;
import java.util.Map;

public class Studentmsg {
	String company;
	String workname;
	String dates;
	String place;
	String tec ;
	String information;
	 private Map<String,String> errors = new HashMap<String,String>();
	 
	 public boolean errormsg() {
		 
		 return true;
	 }
}
