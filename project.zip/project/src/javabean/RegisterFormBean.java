package javabean;

import java.util.HashMap;
import java.util.Map;

public class RegisterFormBean {
	private String username;
	private String password;
	private String password2;
	private String phonenum;
	private String email;
	private String realname;
	public String getRealname() {
		return realname;
	}



	public void setRealname(String realname) {
		this.realname = realname;
	}



	private boolean flag = true;
	 private Map<String,String> errors = new HashMap<String,String>();
	
	
	
    public boolean errormsg() {
    	if(username == null || username.trim().equals("")) {
    		errors.put("username","����������");
    		flag = false;
    	}
    	if(password == null || password.trim().equals("")) {
    		errors.put("password", "����������");
    		flag = false;
    	}else
    	if(password.length()>12||password.length()<6) {
    		errors.put("password", "������6��12���ַ�");
    		flag = false;
    	}
    	if(password != null && !password.equals(password2)) {
    		errors.put("password2", "�����������벻ͬ");
    		flag = false;
    	}
    	if(email == null || email.trim().equals("")) {
    		errors.put("email", "����������");
    		flag = false;
    	}
    	if(phonenum == null || phonenum.trim().equals("")) {
    		errors.put("phonenum", "�������ֻ���");
    		flag = false;
    	}
    	
    	//else if(!email.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$")) {
    	//	errors.put("email", "�����ʽ����");
    	//	flag = false;
    	//}
    	return flag;
    	
    	
    	
    	
    	
    }



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getPassword2() {
		return password2;
	}



	public void setPassword2(String password2) {
		this.password2 = password2;
	}



	public String getPhonenum() {
		return phonenum;
	}



	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Map<String, String> getErrors() {
		return errors;
	}



	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
    
}
